AFTERPACT — Judge Evidence Pack (PayPal AI Hackathon 2026)
=====================================================
Date: 2026-11-09 · Commit: a2be8424
Repo: https://github.com/toskaman/afterpact
Demo: https://199.247.9.188.nip.io (live through Dec 15, 2026)

Start with 00_EXECUTIVE_BRIEF.pdf (60-second verification path inside),
then 05_DEMO_GUIDE.pdf to reproduce the nine acts live.

PDFs (claims, each with sources)          evidence/ (raw artifacts)
--------------------------------          -------------------------
00_EXECUTIVE_BRIEF.pdf                     paypal-live-receipts*.json
01_ARCHITECTURE.pdf                        RELEASE_EVIDENCE_MANIFEST.json
02_PAYPAL_EVIDENCE.pdf                     evals/ (4 runs + summaries)
03_TEST_RESULTS.pdf                        postman/ (collection + Newman)
04_SECURITY_AND_TRUST.pdf                  screenshots/ (15 app captures)
05_DEMO_GUIDE.pdf                          VIDEO_QA_REPORT.md + SHOT_MAP
                                           channel3-live-report.json

Honesty posture: mock transport and recorded runs are always labeled in-app
and in this pack. Nothing simulated is presented as live. All secrets redacted.
